package pr030405Barracks.models.units;

public class Gunner extends AbstractUnit {

	public Gunner() {
		super(20, 20);
	}
}
