package pr030405Barracks.models.units;

public class Horseman extends AbstractUnit {

	public Horseman() {
		super(50, 10);
	}
}
