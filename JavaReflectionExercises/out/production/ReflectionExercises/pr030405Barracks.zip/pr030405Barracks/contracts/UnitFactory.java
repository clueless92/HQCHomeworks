package pr030405Barracks.contracts;

public interface UnitFactory {

    Unit createUnit(String unitType);
}