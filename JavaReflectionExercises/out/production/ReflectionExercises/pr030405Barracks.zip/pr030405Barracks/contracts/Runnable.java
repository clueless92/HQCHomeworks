package pr030405Barracks.contracts;

public interface Runnable {

	void run();
}
