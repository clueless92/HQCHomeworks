package pr030405Barracks.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
