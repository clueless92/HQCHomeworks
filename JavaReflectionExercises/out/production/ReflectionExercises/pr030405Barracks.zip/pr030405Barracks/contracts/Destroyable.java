package pr030405Barracks.contracts;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
