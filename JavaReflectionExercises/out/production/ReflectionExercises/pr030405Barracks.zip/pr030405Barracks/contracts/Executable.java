package pr030405Barracks.contracts;

public interface Executable {

	String execute();
}
