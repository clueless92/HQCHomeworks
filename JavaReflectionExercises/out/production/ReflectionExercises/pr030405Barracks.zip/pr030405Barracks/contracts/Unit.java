package pr030405Barracks.contracts;

public interface Unit extends Destroyable, Attacker {
}
