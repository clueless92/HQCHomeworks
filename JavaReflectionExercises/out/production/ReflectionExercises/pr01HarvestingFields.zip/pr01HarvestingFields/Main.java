package pr01HarvestingFields;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class Main {
	public static void main(String[] args) throws Exception {
		Class test = Class.forName("pr01HarvestingFields.RichSoilLand");
		Field[] fields = test.getDeclaredFields();

		BufferedReader reader = new BufferedReader(
				new InputStreamReader(System.in));
		while (true) {
			String input = reader.readLine();
			if (input.equals("HARVEST")) {
				break;
			}

			for (Field field : fields) {
				int mod = field.getModifiers();
				String modString = Modifier.toString(mod);
				if (!modString.equals(input) && !input.equals("all")) {
					continue;
				}

				String fieldName = field.getName();
				String fieldTypeName = field.getType().getSimpleName();
				System.out.printf("%s %s %s%n",
						modString, fieldTypeName, fieldName);
			}
		}
	}
}
